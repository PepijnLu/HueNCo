using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.Netcode;
using TMPro;
using UnityEngine.Tilemaps;

public class PlayerMovement : NetworkBehaviour
{
    float horizontalInput;
    float verticalInput;
    float moveSpeed = 5f;
    Vector2 movement;
    Rigidbody2D rb;
    public Camera playerCam;
    public int playerInt;
    public TextMeshProUGUI viewText, enterText;
    public Vector3 mousePosition;
    public UnityEngine.Rendering.Universal.Light2D playerLight;
    public float speed;
    // Start is called before the first frame update
    void Start()
    {
        //StartCoroutine(WaitForStart());
        speed = 5f;

    }
    // Update is called once per frame++
    void Update()
    {
        if (IsOwner && (playerInt > 1))
        {
            horizontalInput = Input.GetAxis("Horizontal");
            verticalInput = Input.GetAxis("Vertical");

            movement = new Vector2(horizontalInput, verticalInput).normalized;
        }

        if ((playerInt == 1))
        {
            Vector3 originalMousePosition = Input.mousePosition;

            // Convert the mouse position from screen space to world space
            Vector3 mouseWorldPosition = playerCam.ScreenToWorldPoint(originalMousePosition);
            // Set the position of the object to the mouse position
            mousePosition = new Vector3(mouseWorldPosition.x, mouseWorldPosition.y, 0);
            
        }

    }

    void FixedUpdate()
    {
        // Move the character
        if (rb != null)
        {
            rb.velocity = new Vector2(horizontalInput * speed, verticalInput * speed);
        }
    }

    IEnumerator WaitForStart()
    {
        yield return new WaitForSeconds(1f);
        CustomStart();
    }
    public void CustomStart()
    {
        if (IsOwner)
        {
            rb = gameObject.GetComponent<Rigidbody2D>();
            Collider2D myCollider = GetComponent<Collider2D>();
            myCollider.isTrigger = false;
            Debug.Log("Custom Start");
            playerCam.gameObject.SetActive(true);
            Camera.main.gameObject.SetActive(false);
            playerCam.depth = 1;

            GameObject[] players = GameObject.FindGameObjectsWithTag("Player");
            foreach (GameObject player in players)
            {
                GameObject playerLight = player.transform.Find("Light 2D").gameObject;
                playerLight.SetActive(true);
            }

            if (Lobby.instance.players.IndexOf(gameObject.GetComponent<NetworkObject>()) < 1)
            {
                DGM.instance.viewText.text = "Designer";
                DGM.instance.whichInstance = 1;
                Debug.Log("Setup Player 1");
                playerInt = 1;
                gameObject.transform.position = new Vector3(1000, 1000, -50);
                playerCam.gameObject.transform.position = GameObject.Find("DesCamPos").transform.position;
                playerCam.orthographicSize = 15;
                
            }

            else if (Lobby.instance.players.IndexOf(gameObject.GetComponent<NetworkObject>()) == 1)
            {
                DGM.instance.viewText.text = "Escaper";
                DGM.instance.objectsTexts.SetActive(false);
                DGM.instance.enterText.gameObject.SetActive(false);
                DGM.instance.whichInstance = 2;
                Debug.Log("Setup Player 2");
                //playerLight.gameObject.SetActive(true);
                playerCam.gameObject.SetActive(true);
                playerInt = 2;
                gameObject.transform.position = GameObject.Find("PlayerSpawn").transform.position + new Vector3(-5f, 0, 0);
                DGM.instance.globalLight.intensity = 0;
                playerCam.gameObject.transform.position = gameObject.transform.position + new Vector3(0f, 0f, -5);
                playerCam.orthographicSize = 5;
                //viewText.text = ("View: Player");
                //enterText.gameObject.SetActive(false);
            }
            else if (Lobby.instance.players.IndexOf(gameObject.GetComponent<NetworkObject>()) == 2)
            {
                DGM.instance.viewText.text = "Escaper";
                DGM.instance.objectsTexts.SetActive(false);
                DGM.instance.enterText.gameObject.SetActive(false);
                DGM.instance.whichInstance = 3;
                Debug.Log("Setup Player 3");
                //playerLight.gameObject.SetActive(true);
                playerCam.gameObject.SetActive(true);
                playerInt = 3;
                gameObject.transform.position = GameObject.Find("PlayerSpawn").transform.position + new Vector3(5f, 0, 0);
                //viewText.text = ("View: Player");
                DGM.instance.globalLight.intensity = 0;
                playerCam.gameObject.transform.position = gameObject.transform.position + new Vector3(0f, 0f, -5);
                playerCam.orthographicSize = 5;
                //enterText.gameObject.SetActive(false);
            }

        }
        else
        {
            playerCam.depth = 0;
        }
    }

    void OnTriggerEnter2D(Collider2D collider)
    {
        //if (IsOwner)
        //{
            LobbyPlayer lobbyPlayer = GetComponent<LobbyPlayer>();
            if (collider.gameObject.tag == "Exit")
            {
                Exit exit = collider.gameObject.GetComponent<Exit>();
                if (lobbyPlayer.playerInt == exit.exitInt)
                {
                    //NetworkShit.instance.ChangePlayersFinishedServerRpc(true);
                    DGM.instance.playersFinished++;
                    Debug.Log("reached the exit");
                }
            }
        //}
    }

    void OnTriggerExit2D(Collider2D collider)
    {
        LobbyPlayer lobbyPlayer = GetComponent<LobbyPlayer>();
        //if (IsOwner)
        //{
            if (collider.gameObject.tag == "Exit")
            {
                Exit exit = collider.gameObject.GetComponent<Exit>();
                if (lobbyPlayer.playerInt == exit.exitInt)
                {
                    DGM.instance.playersFinished--;
                }
            }
        //}
    }

    public void BlowUpTile(Vector3 worldPosition, int i)
    {
        if (IsOwner)
        {
            BlowUpTileServerRpc(worldPosition, i);
        }
    }

    [ServerRpc]
    private void BlowUpTileServerRpc(Vector3 worldPosition, int i)
    {
        GameObject tilemapObj = GameObject.FindGameObjectWithTag("CollisionMap");
        Tilemap tilemap = tilemapObj.GetComponent<Tilemap>();
        Vector3Int cellPosition = tilemap.WorldToCell(worldPosition);
        if (tilemap.HasTile(cellPosition))
        {
            tilemap.SetTile(cellPosition, null);
        }
        if (i >= 0)
        {
            Destroy(DGM.instance.objectsList[i]);
        }
        BlowUpTileClientRpc(worldPosition, i);
        
    }

    [ClientRpc]
    private void BlowUpTileClientRpc(Vector3 worldPosition, int i)
    {   
        GameObject tilemapObj = GameObject.FindGameObjectWithTag("CollisionMap");
        Tilemap tilemap = tilemapObj.GetComponent<Tilemap>();
        Vector3Int cellPosition = tilemap.WorldToCell(worldPosition);
        if (tilemap.HasTile(cellPosition))
        {
            tilemap.SetTile(cellPosition, null);
        }
        if (i >= 0)
        {
            Destroy(DGM.instance.objectsList[i]);
        }
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class GameData
{
    public static float paintGameScore;
    public static float mazeGameScore;
    public static float totalScore;
    public static float paintMinigamesPlayed;
}
